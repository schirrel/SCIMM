# SCIMM
![Licensa GPL V3](https://img.shields.io/badge/License-GPL%20v3-blue.svg) ![Build Status](https://travis-ci.org/CoderSquirrel/SCIMM.svg?branch=SCIMM_OO)
##### Sistema desenvolvido na UFMS campus CPCX em forma de Trabalho de Conclusão de Curso para a Equipe de Futebol de Robos Cedro

Requisitos: OpenCV, Qt
Linguagem: C++

